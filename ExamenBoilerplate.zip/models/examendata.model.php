<?php
require_once "libs/dao.php";

// Elaborar el algoritmo de los solicitado aquí.


?>
